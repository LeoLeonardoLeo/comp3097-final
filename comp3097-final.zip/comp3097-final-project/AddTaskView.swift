//
//  AddTaskView.swift
//  comp3097-final-project
//
//  Created by Tech on 2025-02-25.
//

import SwiftUI

struct AddTaskView: View {
    @State var taskText: String = ""
    var body: some View {
        ScrollView{
            TextField("What's the Task?", text: $taskText)
                .frame(height: 70)
                .cornerRadius(30)
                .background(Color.gray.opacity(0.4))
            Button(action: {
            }, label: {
                Text("Save")
                    .frame(height: 70)
                    .frame(width: 80)
                    .background(Color.gray.opacity(0.5))
                    .cornerRadius(20)
                    .foregroundColor(.white)
                    .padding()
            })
            .navigationTitle("Write your Task Type")
        }
    }
}

struct AddTaskView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView{
            AddTaskView()
        }
    }
}
