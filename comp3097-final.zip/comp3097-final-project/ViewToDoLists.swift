import SwiftUI

struct ViewToDoLists: View {
    @State private var items: [String] = [
        "Type 1",
        "Type 2",
        "Type 3"
    ]
    @State private var isEditing = false
    @State private var newTaskType: String = ""
    @State private var isAddingNewType = false

    var body: some View {
        NavigationView {
            VStack {
                List {
                    ForEach(items, id: \.self) { item in
                        NavigationLink(destination: CreateTask(taskType: item)) {
                            ListRowView(title: item)
                        }
                    }
                    .onDelete(perform: delete)
                }
                .listStyle(PlainListStyle())
                
                // if we adding we have to show it
                if isAddingNewType {
                    TextField("Enter New Task Type", text: $newTaskType)
                        .padding()
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .background(Color.gray.opacity(0.1))
                        .cornerRadius(8)
                        .padding()

                    Button("Add Task Type") {
                        // add stuff to our existing list
                        if !newTaskType.isEmpty {
                            items.append(newTaskType)
                            newTaskType = ""
                            isAddingNewType = false
                        }

                    }
                    .frame(height: 50)
                    .frame(maxWidth: .infinity)
                    .background(Color.gray.opacity(0.5))
                    .cornerRadius(10)
                    .foregroundColor(.white)
                    .padding()
                } else {
                    Button("Add Type") {
                        isAddingNewType = true
                    }
                    .frame(height: 50)
                    .frame(maxWidth: .infinity)
                    .background(Color.gray)
                    .cornerRadius(10)
                    .foregroundColor(.white)
                    .padding()
                }
               
            }
            .navigationTitle("Task Types")
        }
    }

    private func delete(at offsets: IndexSet) {
        items.remove(atOffsets: offsets)
    }
}

struct ListRowView: View {
    var title: String
    
    var body: some View {
        Text(title)
            .padding()
            .background(Color.gray.opacity(0.1))
            .cornerRadius(8)
    }
}

struct ViewToDoLists_Previews: PreviewProvider {
    static var previews: some View {
        ViewToDoLists()
    }
}
