//
//  Entity+CoreDataProperties.swift
//  comp3097-project
//
//  Created by Tech on 2025-03-11.
//
//

import Foundation
import CoreData


extension Entity {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Entity> {
        return NSFetchRequest<Entity>(entityName: "Entity")
    }

    @NSManaged public var createdAt: Date?
    @NSManaged public var attribute: NSObject?

}

extension Entity : Identifiable {

}
