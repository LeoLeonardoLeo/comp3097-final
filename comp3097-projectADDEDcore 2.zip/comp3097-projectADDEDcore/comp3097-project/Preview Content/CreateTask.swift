import SwiftUI
import CoreData

struct CreateTask: View {
    @Environment(\.managedObjectContext) private var viewContext
    
    @State private var taskName = ""
    @State private var lastCompleted = Date()
    
    var taskType: String
    
    @State private var taskTypeFromDB: Task_Type?

    init(taskType: String) {
        self.taskType = taskType
    }
    
    func createTask() {
        let newTask = Task(context: viewContext)
        newTask.title = taskName
        newTask.createdAt = Date()
        newTask.isComplete = false
        newTask.lastCompleted = lastCompleted
        newTask.type = taskTypeFromDB // Assign the fetched task type
        
        do {
            try viewContext.save()
            print("Task created successfully")
            taskName = "" // Clear the task name field
        } catch {
            print("Failed to create task: \(error.localizedDescription)")
        }
    }

    func fetchTaskType() {
        // Fetch the Task_Type based on the passed taskType string
        let fetchRequest: NSFetchRequest<Task_Type> = Task_Type.fetchRequest()
        fetchRequest.predicate = NSPredicate(format: "title == %@", taskType)
        
        do {
            let result = try viewContext.fetch(fetchRequest)
            if let taskType = result.first {
                taskTypeFromDB = taskType // Assign the fetched task type to taskTypeFromDB
            } else {
                print("No task type found with title: \(taskType)")
            }
        } catch {
            print("Failed to fetch task type: \(error.localizedDescription)")
        }
    }

    var body: some View {
        NavigationStack {
            VStack(spacing: 10) {
                Text("Create Task for \(taskType)")
                    .font(.headline)
                
                TextField("Enter Task Name", text: $taskName)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding(.horizontal)

                Text("Due By")
                    .font(.subheadline)
                
                DatePicker("", selection: $lastCompleted, displayedComponents: [.date, .hourAndMinute])
                    .labelsHidden()
                    .padding(.horizontal)

                Button("Add Task") {
                    createTask()
                }
                .buttonStyle(.borderedProminent)
                .padding(.top, 5)

                Spacer()
            }
            .padding()
            .onAppear {
                fetchTaskType()  
            }
            .navigationTitle("Create Task")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}

struct CreateTask_Previews: PreviewProvider {
    static var previews: some View {
        CreateTask(taskType: "Type 1")
    }
}
