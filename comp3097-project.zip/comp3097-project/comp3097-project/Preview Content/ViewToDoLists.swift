import SwiftUI

struct ViewToDoLists: View {
    @State private var items: [String] = [] //replace with database
    @State private var isEditing = false
    @State private var newTaskType: String = ""
    @State private var isAddingNewType = false
    @State private var selectedTask: String? //selected task for navigation to fix thing where when the edit/delete is clicked it doesnt delete it goes to next window

    var body: some View {
        NavigationView {
            VStack {
                

                List {
                    ForEach(items, id: \.self) { item in
                        HStack {
                            Button(action: {
                                selectedTask = item
                            }) {
                                ListRowView(title: item)
                                    .frame(maxWidth: .infinity, alignment: .leading)
                            }
                            .buttonStyle(PlainButtonStyle())
                            
                            Spacer()
                            
                            //edit button
                            Button(action: {
                                
                            }) {
                                Image(systemName: "pencil")
                                    .foregroundColor(.blue)
                                    .padding(10)
                            }
                            
                            //delete button
                            Button(action: {
                                deleteTask(item)
                            }) {
                                Image(systemName: "trash")
                                    .foregroundColor(.red)
                                    .padding(10)
                            }
                        }
                        .frame(height: 50)
                    }
                }
                .listStyle(PlainListStyle())

                if isAddingNewType {
                    TextField("Enter New Task Type", text: $newTaskType)
                        .padding()
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .background(Color.gray.opacity(0.1))
                        .cornerRadius(8)
                        .padding()

                    Button("Add Task Type") {
                        if !newTaskType.isEmpty {
                            items.append(newTaskType)
                            newTaskType = ""
                            isAddingNewType = false
                        }
                    }
                    .frame(height: 50)
                    .frame(maxWidth: .infinity)
                    .background(Color.gray.opacity(0.5))
                    .cornerRadius(10)
                    .foregroundColor(.white)
                    .padding()
                }
                
                else {
                    Button("Add Type") {
                        isAddingNewType = true
                    }
                    .frame(height: 50)
                    .frame(maxWidth: .infinity)
                    .background(Color.gray)
                    .cornerRadius(10)
                    .foregroundColor(.white)
                    .padding()
                }

                //navigation logic
                NavigationLink(
                    destination: CreateTask(taskType: selectedTask ?? ""),
                    isActive: Binding(
                        get: { selectedTask != nil },
                        set: { if !$0 { selectedTask = nil } }
                    )
                ) { EmptyView() }
            }
            .navigationTitle("Task Types")
        }
    }

    private func deleteTask(_ task: String) {
        if let index = items.firstIndex(of: task) {
            items.remove(at: index)
        }
    }

    
}

struct ListRowView: View {
    var title: String
    
    var body: some View {
        Text(title)
            .padding()
            .background(Color.gray.opacity(0.1))
            .cornerRadius(8)
    }
}

struct ViewToDoLists_Previews: PreviewProvider {
    static var previews: some View {
        ViewToDoLists()
    }
}
