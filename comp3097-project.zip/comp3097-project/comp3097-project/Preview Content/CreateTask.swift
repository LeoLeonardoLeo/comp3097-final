import SwiftUI

struct CreateTask: View {
    @State private var taskName = ""
    @State private var tasks: [String] = []
    @State private var dueDate = Date()
    
    let printDate: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        formatter.timeStyle = .short
        return formatter
    }()
 
    var taskType: String

    func newTaskInList() {
        let formattedDate = printDate.string(from: dueDate)
        let taskWithDueDate = "\(taskName), Due: \(formattedDate)"
        tasks.append(taskWithDueDate)
        taskName = ""
    }

    func deleteTask(at offsets: IndexSet) {
        tasks.remove(atOffsets: offsets)
    }

    var body: some View {
        NavigationStack {
            VStack(spacing: 15) { //fixes spacing problem with empty space
                Text("Create Task for \(taskType)")
                    .font(.headline)
                
                TextField("Enter Task Name", text: $taskName)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding(.horizontal)

                Text("Due By")
                    .font(.subheadline)
                
                DatePicker("", selection: $dueDate, displayedComponents: [.date, .hourAndMinute])
                    .labelsHidden()
                    .padding(.horizontal)

                Button("Add Task") {
                    newTaskInList()
                }
                .buttonStyle(.borderedProminent)
                .padding(.top, 5)

                Spacer()

                List {
                    ForEach(tasks, id: \.self) { task in
                        HStack {
                            Text(task)
                            
                            Spacer()
                            
                            Button(action: {
                                if let index = tasks.firstIndex(of: task) {
                                    tasks.remove(at: index)
                                }
                            }) {
                                Image(systemName: "trash")
                                    .foregroundColor(.red)
                            }
                            .padding(.trailing, 10)
                        }
                    }
                    .onDelete(perform: deleteTask)
                }
                .listStyle(PlainListStyle())
                .frame(minHeight: 200)  
                
                Spacer()
            }
            .padding()
            .navigationTitle("Create Task")
            .navigationBarTitleDisplayMode(.inline)
            
        }
    }
}

struct CreateTask_Previews: PreviewProvider {
    static var previews: some View {
        CreateTask(taskType: "Type 1")
    }
}
