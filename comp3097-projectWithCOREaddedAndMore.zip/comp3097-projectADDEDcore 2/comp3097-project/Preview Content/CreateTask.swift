import SwiftUI
import CoreData

struct CreateTask: View {
    @Environment(\.managedObjectContext) private var viewContext
    
    @State private var taskName = ""
    @State private var lastCompleted = Date()
    
    var taskType: String
    
    @State private var taskTypeFromDB: Task_Type?

    init(taskType: String) {
        self.taskType = taskType
    }
    
    func createTask() {
        fetchTaskType { success in
            if success, let taskTypeFromDB = taskTypeFromDB {
                let newTask = Task(context: viewContext)
                newTask.title = taskName
                newTask.createdAt = Date()
                newTask.isComplete = false
                newTask.lastCompleted = lastCompleted
                newTask.type = taskTypeFromDB

                do {
                    try viewContext.save()
                    print("Task created successfully")
                    taskName = "" // Clear the task name field
                } catch {
                    print("Failed to create task: \(error.localizedDescription)")
                }
            } else {
                print("No task type found. Unable to create task.")
            }
        }
    }

    func fetchTaskType(completion: @escaping (Bool) -> Void) {
        let fetchRequest: NSFetchRequest<Task_Type> = Task_Type.fetchRequest()
        fetchRequest.predicate = NSPredicate(format: "title == %@", taskType)
        
        do {
            let result = try viewContext.fetch(fetchRequest)
            if let fetchedTaskType = result.first {
                taskTypeFromDB = fetchedTaskType
                print("Fetched Task Type: \(fetchedTaskType.title ?? "No Type")")
                completion(true) //task type fetched successfully
            } else {
                print("No task type found called: \(taskType)")
                completion(false) //no task type
            }
        } catch {
            print("Failed to get task type: \(error.localizedDescription)")
            completion(false) //failed
        }
    }

    var body: some View {
        NavigationStack {
            VStack(spacing: 10) {
                Text("Create Task for \(taskType)")
                    .font(.headline)
                
                TextField("Enter Task Name", text: $taskName)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding(.horizontal)

                Text("Due By")
                    .font(.subheadline)
                
                DatePicker("", selection: $lastCompleted, displayedComponents: [.date, .hourAndMinute])
                    .labelsHidden()
                    .padding(.horizontal)

                Button("Add Task") {
                    createTask()
                }
                .buttonStyle(.borderedProminent)
                .padding(.top, 5)

                Spacer()
            }
            .padding()
            .onAppear {
                fetchTaskType { success in
                    if !success {
                        print("Error: Could not fetch task type")
                    }
                }
            }
            .navigationTitle("Create Task")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}

struct CreateTask_Previews: PreviewProvider {
    static var previews: some View {
        CreateTask(taskType: "Type 1")
    }
}
