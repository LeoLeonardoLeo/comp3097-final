import SwiftUI
import CoreData

extension DateFormatter {
    static var shortDateFormatter: DateFormatter {
        let formatter = DateFormatter()
        formatter.dateStyle = .short
        return formatter
    }
}

struct ContentView: View {
    @Environment(\.managedObjectContext) private var viewContext
    
    @FetchRequest(sortDescriptors: [
        NSSortDescriptor(keyPath: \Task.createdAt, ascending: false)
    ]) var tasks: FetchedResults<Task>
    
    var body: some View {
        NavigationStack {
            VStack {
                
                //navigation to ViewToDoLists
                NavigationLink(destination: ViewToDoLists()) {
                    Text("View All Tasks")
                        .padding()
                }
                
                Text("Upcoming Tasks")
                    .font(.system(size: 22))
                    .padding(.top, 10)
                
                List {
                    ForEach(tasks) { task in
                        VStack(alignment: .leading) {
                            Text(task.title ?? "Untitled Task")
                                .font(.headline)
                            
                            Text("Due: \(task.createdAt ?? Date(), formatter: DateFormatter.shortDateFormatter)")
                                .font(.subheadline)
                                .foregroundColor(.gray)
                            
                            Text(task.isComplete ? "Completed" : "Incomplete")
                                .font(.subheadline)
                                .foregroundColor(task.isComplete ? .green : .red)
                            
                            if let taskType = task.type {
                                Text(taskType.title ?? "No Type")
                                    .font(.subheadline)
                                    .foregroundColor(.blue)
                            } else {
                                Text("No Task Type")
                                    .font(.subheadline)
                                    .foregroundColor(.gray)
                            }
                        }
                    }
                }
                .navigationTitle("To Do List")
                .navigationBarTitleDisplayMode(.large)
            }
        }
    }
}


