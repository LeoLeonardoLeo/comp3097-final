import SwiftUI
import CoreData

struct CreateTask: View {
    @Environment(\.managedObjectContext) private var viewContext
    
    @State private var taskName = ""
    @State private var lastCompleted = Date()
    // FIX THIS NOT PRROPERLY REFERENCING TASK TYPE
    @State private var selectedTaskType: Task_Type?
    // ITS NOT PROPERLY REFERNCING TASK TYPE
    @State private var taskTypes: [Task_Type] = []

    var taskType: String

    init(taskType: String) {
        self.taskType = taskType
    }
    func createTask() {
        let newTask = Task(context: viewContext)
        newTask.title = taskName
        newTask.createdAt = Date()
        newTask.isComplete = false
        newTask.lastCompleted = lastCompleted
        newTask.type = selectedTaskType
        
        do {
            try viewContext.save()
            print("Task created successfully")
            taskName = ""
        } catch {
            print("Failed to create task: \(error.localizedDescription)")
        }
    }
    
    func fetchTaskTypes() {
        let fetchRequest: NSFetchRequest<Task_Type> = Task_Type.fetchRequest()
        do {
            taskTypes = try viewContext.fetch(fetchRequest)
        } catch {
            print("Failed to fetch task types: \(error.localizedDescription)")
        }
    }

    var body: some View {
        NavigationStack {
            VStack(spacing: 10) {
                Text("Create Task for \(taskType)")
                    .font(.headline)
                TextField("Enter Task Name", text: $taskName)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding(.horizontal)

                Text("Due By")
                    .font(.subheadline)
                
                DatePicker("", selection: $lastCompleted, displayedComponents: [.date, .hourAndMinute])
                    .labelsHidden()
                    .padding(.horizontal)
                //DOESNT WORK AND THE PICKER IS USELESS!!! IN THIS CONTEXT
                // havent deleted it because i need reference :3
                Picker("Task Type", selection: $selectedTaskType) {
                    ForEach(taskTypes, id: \.self) { taskType in
                        Text(taskType.title ?? "No Type").tag(taskType as Task_Type?)
                    }
                }
                .pickerStyle(MenuPickerStyle())
                .padding()
                Button("Add Task") {
                    createTask()
                }
                .buttonStyle(.borderedProminent)
                .padding(.top, 5)

                Spacer()
            }
            .padding()
            .onAppear {
                fetchTaskTypes()
            }
            .navigationTitle("Create Task")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}

struct CreateTask_Previews: PreviewProvider {
    static var previews: some View {
        CreateTask(taskType: "Type 1")
    }
}
